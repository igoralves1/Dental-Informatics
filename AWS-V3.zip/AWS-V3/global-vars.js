const { logger } = require('./logger');

exports.setGlobalVars = () => {
  global.Logger = logger(process.env.logLevel);
};