const { DynamoDB } = require("aws-sdk");

let client = null;

exports.getClient = () => {
  if (client) return client;

  config = {
    endpoint: "http://localhost:8000",
    region: "ap-south-1",
    httpOptions: {
      connectTimeout: 1000,
      timeout: 1000,
    },
  };
  // client = new DynamoDB.DocumentClient(config);
  client = new DynamoDB( config );

  console.log("client: zz", client);

  return client;
};
