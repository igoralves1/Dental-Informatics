class Response {
  data = [] || {};
  count = 0;
  scannedCount = 0;
  lastEvaluatedKeyEncoded = undefined;
}

exports.IResponse = Response;
