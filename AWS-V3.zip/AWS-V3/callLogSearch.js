// const { setGlobalVars } = require("./global-vars");
const responses = require("./api_responses");
const { CallLogSearch } = require("./data/call-log-search");

const logCat = "CallLogSearch";

module.exports.handler = async (event) => {
  const logSubCat = `${logCat}-handler`;
  // setGlobalVars();

  Logger.info({
    logCat,
    logSubCat,
    message: "Event data",
    data: event?.body,
  });

  Logger.info({
    logCat,
    logSubCat,
    message: "Headers data",
    data: event.headers,
  });

  try {
    const body = JSON.parse(event.body);
    const type = body?.type || null;
    const id = body?.id || null;
    const startDate = body?.start_date || null;
    const endDate = body?.end_date || null;
    const fromNumber = body?.from_number || null;
    const toNumber = body?.to_number || null;
    const direction = body?.direction || null;
    const status = body?.status || null;
    const size = body?.size || null;
    const page = body?.page || null;

    if (!type) {
      return responses._400({ error: "Type of search is required" });
    }

    const search = new CallLogSearch(type);
    let error;
    let result = [];

    if (id) {
      [error, result] = await search.getById(
        id,
        startDate,
        endDate,
        size,
        page
      );
    } else if (fromNumber || toNumber) {
      [error, result] = await search.getByPhone(
        fromNumber,
        toNumber,
        startDate,
        endDate,
        size,
        page
      );
    } else {
      [error, result] = await search.getByDate(
        startDate,
        endDate,
        status,
        direction,
        size,
        page
      );
    }

    if (error) {
      Logger.error({
        logCat,
        logSubCat,
        message: "Search Retrieve Error",
        data: error,
      });
      return responses._400({ error });
    }

    Logger.info({
      logCat,
      logSubCat,
      message: "Search Retrieved",
      data: `${result.length} records.`,
    });

    return responses._200(result);
  } catch (error) {
    Logger.error({ logCat, logSubCat, message: "Search Error", data: error });

    return responses._400({ error });
  }
};
