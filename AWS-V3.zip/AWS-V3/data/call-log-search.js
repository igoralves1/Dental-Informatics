class CallLogSearch {
  constructor(type) {
    this.type = type;
    this.callLogs = [
      {
        id: "1",
        fromNumber: "1234567890",
        toNumber: "0987654321",
        startDate: "2024-08-01T12:00:00Z",
        endDate: "2024-08-01T12:30:00Z",
        direction: "outbound",
        status: "completed",
      },
      {
        id: "2",
        fromNumber: "1112223333",
        toNumber: "4445556666",
        startDate: "2024-08-02T09:00:00Z",
        endDate: "2024-08-02T09:45:00Z",
        direction: "inbound",
        status: "missed",
      },
      // ... more mock data
    ];
  }

  async getById(id, startDate, endDate, size, page) {
    try {
      let results = this.callLogs.filter((log) => log.id === id);

      if (startDate) {
        results = results.filter(
          (log) => new Date(log.startDate) >= new Date(startDate)
        );
      }
      if (endDate) {
        results = results.filter(
          (log) => new Date(log.endDate) <= new Date(endDate)
        );
      }

      if (size && page) {
        const startIndex = (page - 1) * size;
        results = results.slice(startIndex, startIndex + size);
      }

      return [null, results];
    } catch (error) {
      return [error, []];
    }
  }

  async getByPhone(fromNumber, toNumber, startDate, endDate, size, page) {
    try {
      let results = this.callLogs.filter(
        (log) =>
          (fromNumber ? log.fromNumber === fromNumber : true) &&
          (toNumber ? log.toNumber === toNumber : true)
      );

      if (startDate) {
        results = results.filter(
          (log) => new Date(log.startDate) >= new Date(startDate)
        );
      }
      if (endDate) {
        results = results.filter(
          (log) => new Date(log.endDate) <= new Date(endDate)
        );
      }

      if (size && page) {
        const startIndex = (page - 1) * size;
        results = results.slice(startIndex, startIndex + size);
      }

      return [null, results];
    } catch (error) {
      return [error, []];
    }
  }

  async getByDate(startDate, endDate, status, direction, size, page) {
    try {
      let results = this.callLogs.filter(
        (log) =>
          (!startDate || new Date(log.startDate) >= new Date(startDate)) &&
          (!endDate || new Date(log.endDate) <= new Date(endDate))
      );

      if (status) {
        results = results.filter((log) => log.status === status);
      }
      if (direction) {
        results = results.filter((log) => log.direction === direction);
      }

      if (size && page) {
        const startIndex = (page - 1) * size;
        results = results.slice(startIndex, startIndex + size);
      }

      return [null, results];
    } catch (error) {
      return [error, []];
    }
  }
}

module.exports = { CallLogSearch };
