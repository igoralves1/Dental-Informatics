const AWS = require("aws-sdk");
const moment = require("moment");

const { setGlobalVars } = require("./global-vars");
const responses = require("./api_responses");
const util = require("./util");

const logCat = "BlobUpload";

module.exports.handler = async (event) => {
  const logSubCat = `${logCat}-handler`;

  setGlobalVars();

  Logger.info({
    logCat,
    logSubCat,
    message: "Event data",
    data: event?.body,
  });

  Logger.info({
    logCat,
    logSubCat,
    message: "Headers data",
    data: event?.headers,
  });

  const data = util.parseJson(event.body);
  if (!data) {
    Logger.error({ logCat, logSubCat, message: "Invalid Payload", data: {} });

    return responses._400({ message: "Invalid Payload" });
  }

  Logger.info({
    logCat,
    logSubCat,
    message: "Bucket",
    data: process.env.KITEWHEEL_BUCKET,
  });

  try {
    if (data.name == "undefined" || data.name == "") {
      throw new Error("Name parameter is missing");
    }

    const s3 = new AWS.S3({});

    const regex =
      /(?!(^((2(5[0-5]|[0-4][0-9])|[01]?[0-9]{1,2})\.){3}(2(5[0-5]|[0-4][0-9])|[01]?[0-9]{1,2})$|^xn--|.+-s3alias$))^[a-z0-9][a-z0-9.-_]{1,61}[a-z0-9_]$/;
    let name = new String();
    name = data.name;

    if (!name.match(regex)) {
      throw new Error("Bucket Name is not valid");
    }

    const bucketName = process.env.KITEWHEEL_BUCKET + "/" + name;

    params = {
      Bucket: bucketName,
      Key: `${Math.floor(Math.random() * 1000)}.${moment().unix()}.json`,
      Body: JSON.stringify(data),
    };

    Logger.info({
      logCat,
      logSubCat,
      message: "S3->PutObject Params",
      data: params,
    });

    const result = await s3.upload(params).promise();

    Logger.info({ logCat, logSubCat, message: "S3->PutObject", data: result });

    return responses._200(result);
  } catch (error) {
    Logger.error({
      logCat,
      logSubCat,
      message: "S3->PutObject Error",
      data: error,
    });

    return responses._400({ error: error.message });
  }
};
