const pino = require('pino');

module.exports.logger = (level) => pino({ level });