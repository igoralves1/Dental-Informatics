const AWS = require("aws-sdk");
const { handler } = require("../handler");

jest.mock("aws-sdk");

describe("s3 handler test", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    process.env.KITEWHEEL_BUCKET = "test-bucket";
    process.env.logLevel = "error";
  });

  test('should fail when name starts with underscore e.g "_ftestna_mehyui"', async () => {
    const event = {
      body: JSON.stringify({
        name: "_ftestna_mehyui",
        version: "1",
        data: {
          event: "string",
          timestamp: "timestamp",
          environment: "string",
          properties: {
            user_id: "string",
            application_name: "string",
            payload: [{ field: "string", value: "string" }],
          },
        },
      }),
    };

    const mockS3Instance = {
      upload: jest.fn().mockReturnThis(),
      promise: jest.fn().mockResolvedValue({
        Location: "https://test-bucket.s3.amazonaws.com/file.json",
      }),
    };

    AWS.S3.mockImplementation(() => mockS3Instance);

    const result = await handler(event);

    expect(result.statusCode).toBe(400);
    expect(JSON.parse(result.body).error).toBe("Bucket Name is not valid");
  });

  test('should pass when name is valid e.g "ftestna_mehyui_"', async () => {
    const event = {
      body: JSON.stringify({
        name: "ftestna_mehyui_",
        version: "1",
        data: {
          event: "string",
          timestamp: "timestamp",
          environment: "string",
          properties: {
            user_id: "string",
            application_name: "string",
            payload: [{ field: "string", value: "string" }],
          },
        },
      }),
    };

    const mockS3Instance = {
      upload: jest.fn().mockReturnThis(),
      promise: jest.fn().mockResolvedValue({
        Location: "https://test-bucket.s3.amazonaws.com/file.json",
      }),
    };

    AWS.S3.mockImplementation(() => mockS3Instance);

    const result = await handler(event);

    expect(result.statusCode).toBe(200);
    expect(JSON.parse(result.body).Location).toBe(
      "https://test-bucket.s3.amazonaws.com/file.json"
    );
    expect(mockS3Instance.upload).toHaveBeenCalledWith(
      expect.objectContaining({
        Bucket: "test-bucket/ftestna_mehyui_",
        Key: expect.any(String),
        Body: expect.any(String),
      })
    );
  });
});
