const db = require("./db");
const {
  GetItemCommand,
  PutItemCommand,
  BatchWriteItemCommand,
  QueryCommand,
  ScanCommand,
} = require("@aws-sdk/client-dynamodb");
const { marshall, unmarshall } = require("@aws-sdk/util-dynamodb");
const moment = require("moment");

const getPost = async (event) => {
  const response = { statusCode: 200 };

  try {
    const params = {
      TableName: process.env.DYNAMODB_TABLE_NAME,
      Key: marshall({
        PK: event.pathParameters.postId,
        SK: event.pathParameters.postId,
      }), // Adjust Key as per your schema
    };
    const { Item } = await db.send(new GetItemCommand(params));

    console.log({ Item });
    response.body = JSON.stringify({
      message: "Successfully retrieved post.",
      data: Item ? unmarshall(Item) : {},
      rawData: Item,
    });
  } catch (e) {
    console.error(e);
    response.statusCode = 500;
    response.body = JSON.stringify({
      message: "Failed to get post.",
      errorMsg: e.message,
      errorStack: e.stack,
    });
  }

  return response;
};

const createPost = async (event) => {
  const response = { statusCode: 200 };

  try {
    const body = JSON.parse(event.body);
    const params = {
      TableName: process.env.DYNAMODB_TABLE_NAME,
      Item: marshall(body || {}),
    };
    const createResult = await db.send(new PutItemCommand(params));

    response.body = JSON.stringify({
      message: "Successfully created post.",
      createResult,
    });
  } catch (e) {
    console.error(e);
    response.statusCode = 500;
    response.body = JSON.stringify({
      message: "Failed to create post.",
      errorMsg: e.message,
      errorStack: e.stack,
    });
  }

  return response;
};

const trimSpaceFromRecord = async (event) => {
  const response = { statusCode: 200 };

  try {
    const { startDate, endDate } = JSON.parse(event.body);
    const formattedStartDate = moment(startDate, "YYYY-MM-DD")
      .startOf("month")
      .format("YYYY-MM-DD");

    const formattedEndDate = moment(endDate, "YYYY-MM-DD")
      .endOf("month")
      .format("YYYY-MM-DD");

    const records = await getRecordsBetweenDates(
      formattedStartDate,
      formattedEndDate
    );

    const updatedRecords = records.map((record) => {
      const trimmedName = record.name.trim().replace(/\s+/g, " ");
      return { ...record, name: trimmedName };
    });

    await batchUpdateRecords(updatedRecords);

    response.body = JSON.stringify({
      message: "Records updated successfully",
      updatedRecords,
    });
  } catch (error) {
    console.error(error);
    response.statusCode = 500;
    response.body = JSON.stringify({
      message: "Error updating records",
      error: error.message,
    });
  }

  return response;
};

async function getRecordsBetweenDates(startDate, endDate) {
  const params = {
    TableName: "TableDatesAndName",
    FilterExpression: "createdAt BETWEEN :startDate AND :endDate",
    ExpressionAttributeValues: {
      ":startDate": { S: startDate },
      ":endDate": { S: endDate },
    },
  };

  const command = new ScanCommand(params);
  const data = await db.send(command);
  return data.Items.map((item) => unmarshall(item));
}

async function batchUpdateRecords(records) {
  const BATCH_SIZE = 25;
  const batches = [];

  for (let i = 0; i < records.length; i += BATCH_SIZE) {
    console.log("🚀 ~ batchUpdateRecords ~ records:", records);
    const batch = records.slice(i, i + BATCH_SIZE).map((record) => ({
      PutRequest: {
        Item: marshall(record),
      },
    }));

    batches.push({
      RequestItems: {
        TableDatesAndName: batch,
      },
    });
  }

  for (const batch of batches) {
    const command = new BatchWriteItemCommand(batch);
    await db.send(command);
  }
}

const insertSampleData = async () => {
  const response = { statusCode: 200 };

  const sampleData = [
    {
      PK: "001",
      SK: "2023-07-28",
      GSI1PK: "gsi1-001",
      GSI1SK: "2023-07-28T10:00:00Z",
      GSI2PK: "gsi2-001",
      GSI2SK: "2023-07-28T10:00:00Z",
      GSI3PK: "gsi3-001",
      GSI3SK: "2023-07-28T10:00:00Z",
      GSI4PK: "gsi4-001",
      GSI4SK: "2023-07-28T10:00:00Z",
      ended_reason: "FLOW_END",
      status: "ended",
    },
    {
      PK: "002",
      SK: "2023-07-29",
      GSI1PK: "gsi1-002",
      GSI1SK: "2023-07-29T10:00:00Z",
      GSI2PK: "gsi2-002",
      GSI2SK: "2023-07-29T10:00:00Z",
      GSI3PK: "gsi3-002",
      GSI3SK: "2023-07-29T10:00:00Z",
      GSI4PK: "gsi4-002",
      GSI4SK: "2023-07-29T10:00:00Z",
      ended_reason: "FLOW_END",
      status: "ended",
    },
    {
      PK: "003",
      SK: "2023-07-30",
      GSI1PK: "gsi1-003",
      GSI1SK: "2023-07-30T10:00:00Z",
      GSI2PK: "gsi2-003",
      GSI2SK: "2023-07-30T10:00:00Z",
      GSI3PK: "gsi3-003",
      GSI3SK: "2023-07-30T10:00:00Z",
      GSI4PK: "gsi4-003",
      GSI4SK: "2023-07-30T10:00:00Z",
      ended_reason: "FLOW_END",
      status: "ended",
    },
    {
      PK: "004",
      SK: "2023-07-31",
      GSI1PK: "gsi1-004",
      GSI1SK: "2023-07-31T10:00:00Z",
      GSI2PK: "gsi2-004",
      GSI2SK: "2023-07-31T10:00:00Z",
      GSI3PK: "gsi3-004",
      GSI3SK: "2023-07-31T10:00:00Z",
      GSI4PK: "gsi4-004",
      GSI4SK: "2023-07-31T10:00:00Z",
      ended_reason: "FLOW_END",
      status: "ended",
    },
    {
      PK: "005",
      SK: "2023-08-01",
      GSI1PK: "gsi1-005",
      GSI1SK: "2023-08-01T10:00:00Z",
      GSI2PK: "gsi2-005",
      GSI2SK: "2023-08-01T10:00:00Z",
      GSI3PK: "gsi3-005",
      GSI3SK: "2023-08-01T10:00:00Z",
      GSI4PK: "gsi4-005",
      GSI4SK: "2023-08-01T10:00:00Z",
      ended_reason: "FLOW_END",
      status: "ended",
    },
    {
      PK: "001",
      SK: "2023-07-29",
      GSI1PK: "gsi1-901",
      GSI1SK: "2023-07-28T10:00:00Z",
      GSI2PK: "gsi2-001",
      GSI2SK: "2023-07-28T10:00:00Z",
      GSI3PK: "gsi3-001",
      GSI3SK: "2023-07-28T10:00:00Z",
      GSI4PK: "gsi4-001",
      GSI4SK: "2023-07-28T10:00:00Z",
      ended_reason: "FLOW_END",
      status: "ended",
    },
    {
      PK: "001",
      SK: "2023-07-30",
      GSI1PK: "gsi1-901",
      GSI1SK: "2023-07-28T10:00:00Z",
      GSI2PK: "gsi2-001",
      GSI2SK: "2023-07-28T10:00:00Z",
      GSI3PK: "gsi3-001",
      GSI3SK: "2023-07-28T10:00:00Z",
      GSI4PK: "gsi4-001",
      GSI4SK: "2023-07-28T10:00:00Z",
      ended_reason: "FLOW_END",
      status: "ended",
    },
    {
      PK: "001",
      SK: "2023-07-31",
      GSI1PK: "gsi1-901",
      GSI1SK: "2023-07-28T10:00:00Z",
      GSI2PK: "gsi2-001",
      GSI2SK: "2023-07-28T10:00:00Z",
      GSI3PK: "gsi3-001",
      GSI3SK: "2023-07-28T10:00:00Z",
      GSI4PK: "gsi4-001",
      GSI4SK: "2023-07-28T10:00:00Z",
      ended_reason: "FLOW_END",
      status: "ended",
    },
    {
      PK: "001",
      SK: "2023-08-01",
      GSI1PK: "gsi1-901",
      GSI1SK: "2023-07-28T10:00:00Z",
      GSI2PK: "gsi2-001",
      GSI2SK: "2023-07-28T10:00:00Z",
      GSI3PK: "gsi3-001",
      GSI3SK: "2023-07-28T10:00:00Z",
      GSI4PK: "gsi4-001",
      GSI4SK: "2023-07-28T10:00:00Z",
      ended_reason: "FLOW_END",
      status: "ended",
    },
    {
      PK: "001",
      SK: "2023-08-02",
      GSI1PK: "gsi1-901",
      GSI1SK: "2023-07-28T10:00:00Z",
      GSI2PK: "gsi2-001",
      GSI2SK: "2023-07-28T10:00:00Z",
      GSI3PK: "gsi3-001",
      GSI3SK: "2023-07-28T10:00:00Z",
      GSI4PK: "gsi4-001",
      GSI4SK: "2023-07-28T10:00:00Z",
      ended_reason: "FLOW_END",
      status: "ended",
    },
    {
      PK: "001",
      SK: "2023-08-03",
      GSI1PK: "gsi1-901",
      GSI1SK: "2023-07-28T10:00:00Z",
      GSI2PK: "gsi2-001",
      GSI2SK: "2023-07-28T10:00:00Z",
      GSI3PK: "gsi3-001",
      GSI3SK: "2023-07-28T10:00:00Z",
      GSI4PK: "gsi4-001",
      GSI4SK: "2023-07-28T10:00:00Z",
      ended_reason: "FLOW_END",
      status: "ended",
    },
    {
      PK: "001",
      SK: "2023-08-04",
      GSI1PK: "gsi1-901",
      GSI1SK: "2023-07-28T10:00:00Z",
      GSI2PK: "gsi2-001",
      GSI2SK: "2023-07-28T10:00:00Z",
      GSI3PK: "gsi3-001",
      GSI3SK: "2023-07-28T10:00:00Z",
      GSI4PK: "gsi4-001",
      GSI4SK: "2023-07-28T10:00:00Z",
      ended_reason: "FLOW_END",
      status: "ended",
    },
    {
      PK: "001",
      SK: "2023-08-05",
      GSI1PK: "gsi1-901",
      GSI1SK: "2023-07-28T10:00:00Z",
      GSI2PK: "gsi2-001",
      GSI2SK: "2023-07-28T10:00:00Z",
      GSI3PK: "gsi3-001",
      GSI3SK: "2023-07-28T10:00:00Z",
      GSI4PK: "gsi4-001",
      GSI4SK: "2023-07-28T10:00:00Z",
      ended_reason: "FLOW_END",
      status: "ended",
    },
    {
      PK: "001",
      SK: "2023-08-06",
      GSI1PK: "gsi1-901",
      GSI1SK: "2023-07-28T10:00:00Z",
      GSI2PK: "gsi2-001",
      GSI2SK: "2023-07-28T10:00:00Z",
      GSI3PK: "gsi3-001",
      GSI3SK: "2023-07-28T10:00:00Z",
      GSI4PK: "gsi4-001",
      GSI4SK: "2023-07-28T10:00:00Z",
      ended_reason: "FLOW_END",
      status: "ended",
    },
    {
      PK: "001",
      SK: "2023-08-07",
      GSI1PK: "gsi1-901",
      GSI1SK: "2023-07-28T10:00:00Z",
      GSI2PK: "gsi2-001",
      GSI2SK: "2023-07-28T10:00:00Z",
      GSI3PK: "gsi3-001",
      GSI3SK: "2023-07-28T10:00:00Z",
      GSI4PK: "gsi4-001",
      GSI4SK: "2023-07-28T10:00:00Z",
      ended_reason: "FLOW_END",
      status: "ended",
    },
    {
      PK: "001",
      SK: "2023-08-08",
      GSI1PK: "gsi1-901",
      GSI1SK: "2023-07-28T10:00:00Z",
      GSI2PK: "gsi2-001",
      GSI2SK: "2023-07-28T10:00:00Z",
      GSI3PK: "gsi3-001",
      GSI3SK: "2023-07-28T10:00:00Z",
      GSI4PK: "gsi4-001",
      GSI4SK: "2023-07-28T10:00:00Z",
      ended_reason: "FLOW_END",
      status: "ended",
    },
    {
      PK: "001",
      SK: "2023-08-09",
      GSI1PK: "gsi1-901",
      GSI1SK: "2023-07-28T10:00:00Z",
      GSI2PK: "gsi2-001",
      GSI2SK: "2023-07-28T10:00:00Z",
      GSI3PK: "gsi3-001",
      GSI3SK: "2023-07-28T10:00:00Z",
      GSI4PK: "gsi4-001",
      GSI4SK: "2023-07-28T10:00:00Z",
      ended_reason: "FLOW_END",
      status: "ended",
    },
    {
      PK: "001",
      SK: "2023-08-10",
      GSI1PK: "gsi1-901",
      GSI1SK: "2023-07-28T10:00:00Z",
      GSI2PK: "gsi2-001",
      GSI2SK: "2023-07-28T10:00:00Z",
      GSI3PK: "gsi3-001",
      GSI3SK: "2023-07-28T10:00:00Z",
      GSI4PK: "gsi4-001",
      GSI4SK: "2023-07-28T10:00:00Z",
      ended_reason: "FLOW_END",
      status: "ended",
    },
  ];

  const putRequests = sampleData.map((item) => ({
    PutRequest: {
      Item: marshall(item),
    },
  }));

  const params = {
    RequestItems: {
      [process.env.DYNAMODB_TABLE_NAME]: putRequests,
    },
  };

  try {
    await db.send(new BatchWriteItemCommand(params));
    response.body = JSON.stringify({
      message: "Successfully inserted sample data.",
    });
  } catch (e) {
    console.error(e);
    response.statusCode = 500;
    response.body = JSON.stringify({
      message: "Failed to insert sample data.",
      errorMsg: e.message,
      errorStack: e.stack,
    });
  }

  return response;
};

const insertSampleDataForTableDatesAndName = async () => {
  const response = { statusCode: 200 };

  const sampleData = [
    {
      id: "001",
      createdAt: "2023-07-01",
      name: "abc     def",
    },
    {
      id: "002",
      createdAt: "2023-07-02",
      name: "john    doe",
    },
    {
      id: "003",
      createdAt: "2023-07-03",
      name: "jane    doe",
    },
    {
      id: "004",
      createdAt: "2023-07-04",
      name: "michael  scott",
    },
    {
      id: "005",
      createdAt: "2023-07-05",
      name: "dwight   schrute",
    },
    {
      id: "006",
      createdAt: "2023-07-06",
      name: "pam     beesly",
    },
    {
      id: "007",
      createdAt: "2023-07-07",
      name: "jim     halpert",
    },
    {
      id: "008",
      createdAt: "2023-07-08",
      name: "stanley  hudson",
    },
    {
      id: "009",
      createdAt: "2023-07-09",
      name: "kevin    malone",
    },
    {
      id: "010",
      createdAt: "2023-07-10",
      name: "angela   martin",
    },
    {
      id: "011",
      createdAt: "2023-07-11",
      name: "oscar    martinez",
    },
    {
      id: "012",
      createdAt: "2023-07-12",
      name: "ryan     howard",
    },
    {
      id: "013",
      createdAt: "2023-07-13",
      name: "kelly    kapoor",
    },
    {
      id: "014",
      createdAt: "2023-07-14",
      name: "andy     bernard",
    },
    {
      id: "015",
      createdAt: "2023-07-15",
      name: "toby     flenderson",
    },
    {
      id: "016",
      createdAt: "2023-07-16",
      name: "creed    bratton",
    },
    {
      id: "017",
      createdAt: "2023-07-17",
      name: "meredith palmer",
    },
    {
      id: "018",
      createdAt: "2023-07-18",
      name: "   phyllis  vance    ",
    },
    {
      id: "019",
      createdAt: "2023-07-19",
      name: "darryl   philbin    ",
    },
    {
      id: "020",
      createdAt: "2023-07-20",
      name: "   jan      levinson",
    },
  ];

  const putRequests = sampleData.map((item) => ({
    PutRequest: {
      Item: marshall(item),
    },
  }));

  const params = {
    RequestItems: {
      TableDatesAndName: putRequests,
    },
  };

  try {
    await db.send(new BatchWriteItemCommand(params));
    response.body = JSON.stringify({
      message: "Successfully inserted sample data.",
    });
  } catch (e) {
    console.error(e);
    response.statusCode = 500;
    response.body = JSON.stringify({
      message: "Failed to insert sample data.",
      errorMsg: e.message,
      errorStack: e.stack,
    });
  }

  return response;
};

const getByDate = async (event) => {
  const response = { statusCode: 200 };

  const startDate = event.queryStringParameters.startDate || null;
  const endDate = event.queryStringParameters.endDate || null;
  const gsi1pk = event.queryStringParameters.gsi1pk || null;
  const endedReason = event.queryStringParameters.ended_reason || null;
  const status = event.queryStringParameters.status || null;

  try {
    let stDt, endDt;

    if (startDate && endDate) {
      stDt = { S: moment(`${startDate} 00:00:00`).format() };
      endDt = { S: moment(`${endDate} 23:59:00`).format() };
    } else if (startDate) {
      stDt = { S: moment(`${startDate} 00:00:00`).format() };
      endDt = { S: moment().format() };
    } else if (endDate) {
      stDt = { S: moment(endDate).subtract(1, "days").format() };
      endDt = { S: moment(`${endDate} 23:59:00`).format() };
    } else {
      stDt = { S: moment().subtract(1, "days").format() };
      endDt = { S: moment().format() };
    }

    if (moment(endDt.S).isBefore(moment(stDt.S))) {
      throw new Error("Start Date Must Be Before or Equal to End Date");
    }
    if (!gsi1pk) {
      throw new Error("GSI1PK parameter is required");
    }

    console.log("start : ", stDt, " end data : ", endDt);

    const params = {
      TableName: process.env.DYNAMODB_TABLE_NAME,
      IndexName: "GSI1",
      KeyConditionExpression:
        "GSI1PK = :gsi1pk AND GSI1SK BETWEEN :startdate AND :enddate",
      FilterExpression: "#status = :status AND #ended_reason = :ended_reason",
      ExpressionAttributeNames: {
        "#status": "status",
        "#ended_reason": "ended_reason",
      },
      ExpressionAttributeValues: {
        ":gsi1pk": { S: gsi1pk },
        ":startdate": stDt,
        ":enddate": endDt,
        ":status": { S: status },
        ":ended_reason": { S: endedReason },
      },
      ScanIndexForward: false,
    };
    const result = await db.send(new QueryCommand(params));
    const searches = result.Items.map((item) => unmarshall(item));
    console.log(searches);

    response.body = JSON.stringify({
      message: "Successfully retrieved data.",
      data: searches,
    });
  } catch (e) {
    console.error(e);
    response.statusCode = 500;
    response.body = JSON.stringify({
      message: "Failed to get data.",
      errorMsg: e.message,
      errorStack: e.stack,
    });
  }

  return response;
};

const getByPhone = async (event) => {
  const response = { statusCode: 200 };

  const startDate = event.queryStringParameters.startDate || null;
  const endDate = event.queryStringParameters.endDate || null;
  const gsi1pk = event.queryStringParameters.gsi1pk || null;

  const pageSize = parseInt(event.queryStringParameters.size) || 50;
  const pageNumber = parseInt(event.queryStringParameters.page) || 1;

  if (!gsi1pk) {
    response.statusCode = 400;
    response.body = JSON.stringify({
      message: "GSI1PK parameter is required",
    });
    return response;
  }

  try {
    let stDt, endDt;

    if (startDate && endDate) {
      stDt = { S: moment(`${startDate} 00:00:00`).format() };
      endDt = { S: moment(`${endDate} 23:59:00`).format() };
    } else if (startDate) {
      stDt = { S: moment(`${startDate} 00:00:00`).format() };
      endDt = { S: moment().format() };
    } else if (endDate) {
      stDt = { S: moment(endDate).subtract(1, "days").format() };
      endDt = { S: moment(`${endDate} 23:59:00`).format() };
    } else {
      stDt = { S: moment().subtract(1, "days").format() };
      endDt = { S: moment().format() };
    }

    if (moment(endDt.S).isBefore(moment(stDt.S))) {
      throw new Error("Start Date Must Be Before or Equal to End Date");
    }

    const params = {
      TableName: process.env.DYNAMODB_TABLE_NAME,
      IndexName: "GSI1",
      KeyConditionExpression:
        "GSI1PK = :gsi1pk AND GSI1SK BETWEEN :startdate AND :enddate",
      ExpressionAttributeValues: {
        ":gsi1pk": { S: gsi1pk },
        ":startdate": stDt,
        ":enddate": endDt,
      },
      ScanIndexForward: false,
      Limit: pageSize * (pageNumber + 1),
    };

    const result = await db.send(new QueryCommand(params));
    const items = result.Items.map((item) => unmarshall(item));

    const start = (pageNumber - 1) * pageSize;
    const paginatedItems = items.slice(start, start + pageSize);

    response.body = JSON.stringify({
      message: "Successfully retrieved data.",
      data: paginatedItems,
      nextPage: items.length > start + pageSize ? pageNumber + 1 : null,
    });
  } catch (e) {
    console.error(e);
    response.statusCode = 500;
    response.body = JSON.stringify({
      message: "Failed to get data.",
      errorMsg: e.message,
      errorStack: e.stack,
    });
  }

  return response;
};

const insertRecord = async (event) => {
  const response = { statusCode: 200 };

  try {
    const body = JSON.parse(event.body);
    if (!body.PK || !body.SK) {
      throw new Error("PK and SK are required fields.");
    }

    const params = {
      TableName: process.env.DYNAMODB_TABLE_NAME,
      Item: marshall(body || {}),
    };

    await db.send(new PutItemCommand(params));

    response.body = JSON.stringify({
      message: "Successfully inserted record.",
    });
  } catch (e) {
    console.error(e);
    response.statusCode = 500;
    response.body = JSON.stringify({
      message: "Failed to insert record.",
      errorMsg: e.message,
      errorStack: e.stack,
    });
  }

  return response;
};

module.exports = {
  getPost,
  createPost,
  insertSampleData,
  insertSampleDataForTableDatesAndName,
  trimSpaceFromRecord,
  insertRecord,
  getByDate,
  getByPhone,
};
