const fs = require('fs');
const csv = require("csv-parser");
const { CANCELLED } = require('dns');
const file = process.argv[2];

let results = [];
let records = [ ];

fs.createReadStream(file)
    .pipe(csv())
    .on("data", (data) => {
        results.push(data);
    })
    .on("end", () => {
        run(results);
    });

const run = async (data) => {
    let badDataCNT = 0;
    let addedCNT = 0;
    let results = [];
    let items = [[
        'timestamp',
        'name',
        'event_description',
        'eventtype',
        'resource_type',
        'reservation_timeout',
        'worker_name',
        'transfer_to',
        'transfer_status',
        'transfer_started',
        'transfer_type',
        'worker.full_name',
        'worker.agentId',
        'worker.email',
        'hang_up_by'].join("\t")
    ];
    for (let i = 0; i < data.length; i++ ) {
        try {
            const logMessage = JSON.parse(data[i].message);
            if (logMessage.message && logMessage.message === 'Kinesis Row') {
                const temp = logMessage.data.data;
                const payload = temp.payload;
                if ( payload.eventtype === 'task.transfer-initiated') {
console.log(temp);
                }
                if ( payload.eventtype !== 'worker.activity.update') {
                    let row = [
                        temp.timestamp,
                        temp.name,
                        payload.event_description,
                        payload.eventtype,
                        payload.resource_type,
                        payload.reservation_timeout || '',
                        payload.worker_name,
                        payload.transfer_to || '',
                        payload.transfer_status || '',
                        payload.transfer_started || '',
                        payload.transfer_type || ''
                    ];
    
                    if (payload.task_attributes) {
                        payload.task_attributes = JSON.parse(payload.task_attributes);
                    }
                    if (payload.worker_attributes) {
                        payload.worker_attributes = JSON.parse(payload.worker_attributes);
                    }
    
                    row = [...row, ...[payload.worker_attributes.full_name || '',
                                        payload.worker_attributes.agentId || '',
                                        payload.worker_attributes.email || '',
                                        payload.task_attributes?.conversations.hang_up_by || '']];
    
                    items.push(row.join("\t"));
    
                    //console.log(JSON.stringify(logMessage.data, undefined, 2));
                    results.push(logMessage.data);
                    // console.log("----------------------");
                }
            } else if (logMessage.message && logMessage.message === 'Event ') {
                //console.log(logMessage.data);
                records = [ ...records, ...logMessage.data.Records ];
            }
        } catch (error) {

        }

        addedCNT++;
    }

    fs.writeFile(file.replace('.csv', '.json'), JSON.stringify({ 'Records': records }, undefined, 2), err => {
        if (err) {
            console.error(err);
        } else {
            // File written successfully
        }
    });

    fs.writeFile(file.replace('.csv', '.log'), JSON.stringify(results, undefined, 2), err => {
        if (err) {
            console.error(err);
        } else {
            // File written successfully
        }
    });

    fs.writeFile(file.replace('.csv', '.txt'), items.join("\n"), err => {
        if (err) {
            console.error(err);
        } else {
            // File written successfully
        }
    });

    console.log(`Added CNT: ${addedCNT}`)
    console.log(`Bad Data CNT: ${badDataCNT}`)
}