const fs = require('fs');
const csv = require("csv-parser");
const { DynamoDB } = require("aws-sdk");
const { marshall, unmarshall } = require("@aws-sdk/util-dynamodb");
const util = require('./common/util');

const config  = {
    endpoint: 'http://localhost:8000',
    region: 'us-west-1',
    httpOptions: {
        connectTimeout: 1000,
        timeout: 1000
    }
}
const client = new DynamoDB( config );
const file = process.argv[2];
const DB_TABLE_NAME = 'twilio-video-logs-dev';

console.log(file);

let results = [];
fs.createReadStream(file)
    .pipe(csv())
    .on("data", (data) => {
        results.push(data);
    })
    .on("end", () => {
        run(results);
    });

const toItem = (item) => {
    return {
        sid: { S: item.sid },
        date_time: { S: item.date_time },
        agentName: { S: item.agentName },
        body: { M: marshall(item.body) },
        eventStatus: { S: item.eventStatus },
        fileTransfer: { S: item.fileTransfer },
        meeting_date: { S: item.meeting_date || '' },
        prospectName: { S: item.prospectName },
        RoomSid: { S: item.RoomSid },
        GSI1PK: { S: getGSI1PK(item.date_time)},
        GSI1SK: { S: getGSI1SK(item.sid)},
        ...(item.agentName ? {GSI2PK: { S: getGSI2PK(item.date_time) }} : {}),
        ...(item.agentName ? {GSI2SK: { S: getGSI2SK(item.agentName) }} : {}),
        ...(item.prospectName ? {GSI3PK: { S: getGSI3PK(item.date_time) }} : {}),
        ...(item.prospectName ? {GSI3SK: { S: getGSI3SK(item.prospectName) }} : {})
    }
}

const getGSI1PK = (value) => {
    return `SEARCH_ID#${util.getShardId(value)}`;
}

const getGSI1SK = (value) => {
    return value;
}

const getGSI2PK = (value) => {
    return `SEARCH_AGENT#${util.getShardId(value)}`;
}

const getGSI2SK = (value) => {
    return value;
}

const getGSI3PK = (value) => {
    return `SEARCH_PROSPECT#${util.getShardId(value)}`;
}

const getGSI3SK = (value) => {
    return value;
}

const run = async (data) => {
    let badDataCNT = 0;
    let addedCNT = 0;
    for (let i = 0; i < data.length; i++ ) {
        data[i].body = unmarshall(JSON.parse(data[i].body));
        data[i].agentName = data[i].agentName.replaceAll('"', '').trim();
        data[i].prospectName = data[i].prospectName.replaceAll('"', '').trim();

        if (!data[i].agentName || !data[i].prospectName) {
            badDataCNT++;
            continue;
        }

        if (data[i].agentName.startsWith('"') ||
            data[i].prospectName.startsWith('"') ||
            data[i].agentName.includes('  ')) {

        }

        if (data[i].agentName === 'JUAN RUIZ') {
            data[i].agentName = data[i].agentName.replace(' ', '  ');
        }

        if (data[i].prospectName === 'JAIR MEMBER') {
            data[i].prospectName = data[i].prospectName.replace(' ', '  ');
        }

        // console.log(toItem(data[i]))
        const result = await client
            .putItem({
                TableName: DB_TABLE_NAME,
                Item: toItem(data[i]),
                ConditionExpression: "attribute_not_exists(PK)"
            }).promise();

        addedCNT++;
    }

    console.log(`Added CNT: ${addedCNT}`)
    console.log(`Bad Data CNT: ${badDataCNT}`)
}