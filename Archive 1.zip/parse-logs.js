const fs = require('fs');
const csv = require("csv-parser");
const file = process.argv[2];

let results = [];
fs.createReadStream(file)
    .pipe(csv())
    .on("data", (data) => {
        results.push(data);
    })
    .on("end", () => {
        parse(results);
    });

const parse = async (data) => {
    let results = { "Records": [ ] };

    for (let i = 0; i < data.length; i++ ) {
        try {
            const logMessage = JSON.parse(data[i].message);
            if (logMessage.message && logMessage.message.trim() === 'Event') {
                results.Records = [ ...results.Records, ...logMessage.data.Records ];
            }

        } catch (error) {

        }
    }

    fs.writeFile(file.replace('.csv', '.json'), JSON.stringify(results, undefined, 2), err => {
        if (err) {
            console.error(err);
        } else {
            // File written successfully
        }
    });

    console.log(`==> CNT: ${results.Records.length}`)
}