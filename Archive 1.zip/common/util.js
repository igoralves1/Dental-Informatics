const moment = require('moment');

const extractError = (error) => {
    return { code: error.statusCode, message: error.message };
}

const extractType = (value) => {
    const type = value.split('.');

    return type.length > 4 ? type.slice(0, -2).join('.') : type.join('.');
}

const getShardId = (value) => {
    if (!value) return '';

    const getQuarter = (date) => {
        const year = date.getFullYear();
        const quarter = Math.floor((date.getMonth() + 3) / 3);

        return `${year}0${quarter}`;
    }

    const date = new Date(`${moment(value).format('YYYY-MM-DD')} 12:00`);

    return getQuarter(date);
}

const getShardRange = (start, end) => {
    const startDate = moment(`${start} 12:00:00`).format();
    let endDate = moment(`${end} 23:59:00`).format();

    let results = [];
    while (endDate > startDate) {
        endDate = moment(endDate).subtract(1, 'months').format();
        const shardId = getShardId(endDate);

        if (!results.includes(shardId)) {
            results.push(shardId);
        }
    }

    return results;
}

const formatPhone = (value) => {
    return value ? value.replace('+', '').replaceAll(' ', '') : "";
}

const parseJson = (value) => {
    try {
        return JSON.parse(value);
    } catch (error) {
        return null;
    }
}

module.exports = {
    extractError,
    extractType,
    formatPhone,
    getShardId,
    getShardRange,
    parseJson
};